CRUD and Postgres setup for Proyecto

Quick steps (Windows PowerShell):

1) Create virtualenv and install deps

```powershell
.\scripts\setup_venv.ps1
```

2) Ensure Postgres is running locally (or set `PG_ADMIN_DSN` env var):

- Example `PG_ADMIN_DSN` (PowerShell):

```powershell
$env:PG_ADMIN_DSN = "host=localhost dbname=postgres user=postgres password=mi_password"
```

3) Create DB and user (script will create `proyecto_user` / `proyecto_db` by default):

```powershell
python .\scripts\setup_postgres.py
```

4) Set application DATABASE_URL environment variable used by SQLAlchemy:

```powershell
$env:DATABASE_URL = "postgresql+psycopg2://proyecto_user:proyecto_pass@localhost:5432/proyecto_db"
```

5) Seed initial data

```powershell
python -m crud.seed
```

Files added:
- `crud/models.py` - SQLAlchemy models
- `crud/db.py` - engine/session helpers
- `crud/seed.py` - seed data
- `scripts/setup_postgres.py` - create user/db
- `scripts/setup_venv.ps1` - create venv & install
- `requirements.txt` - dependencies list

Notes:
- Scripts expect Postgres accessible on localhost unless you change env vars.
- Use secure credentials in production; these scripts are convenience helpers for local dev.

---

## Notas adicionales

- El `README.md` principal contiene información general del proyecto y enlaces rápidos. Ver: `README.md`.
- Los registros de la aplicación se escriben en `restaurante.log` en la raíz del proyecto.
- El repositorio ignora `__pycache__/`, `.vscode/` y `venv/` mediante `.gitignore`.

