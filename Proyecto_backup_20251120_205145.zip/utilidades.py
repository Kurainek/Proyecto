"""Utilidades y validadores reusables para Proyecto.

Contiene funciones para formateo, cálculos y validación.
"""
from typing import Iterable, List
import os


# -- Formateo ---------------------------------------------------------------

def format_price(value: float, moneda: str = "$") -> str:
    """Formatea un número como precio con 2 decimales y símbolo de moneda."""
    try:
        return f"{moneda}{float(value):.2f}"
    except Exception:
        return f"{moneda}0.00"


def format_quantity(value: float) -> str:
    """Formatea cantidades (elimina ceros redundantes)."""
    try:
        if float(value).is_integer():
            return str(int(value))
        return f"{float(value):.2f}"
    except Exception:
        return "0"


# -- Cálculos ---------------------------------------------------------------

def calcular_total_items(items: Iterable[dict]) -> float:
    """Calcula el total dado un iterable de items con keys 'cantidad' y 'precio_unitario'."""
    total = 0.0
    for it in items:
        try:
            total += float(it.get("cantidad", 0)) * float(it.get("precio_unitario", 0))
        except Exception:
            continue
    return float(total)


# -- Archivos ---------------------------------------------------------------

def ensure_dir_for_file(path: str) -> None:
    """Crea directorio padre para `path` si no existe."""
    d = os.path.dirname(os.path.abspath(path))
    if d and not os.path.exists(d):
        os.makedirs(d, exist_ok=True)


# -- Validación ------------------------------------------------------------

def is_positive_number(value) -> bool:
    try:
        return float(value) >= 0
    except Exception:
        return False


def is_alpha_space(value: str) -> bool:
    if value is None:
        return False
    return all(ch.isalpha() or ch.isspace() for ch in value)


__all__ = [
    "format_price",
    "format_quantity",
    "calcular_total_items",
    "ensure_dir_for_file",
    "is_positive_number",
    "is_alpha_space",
]
