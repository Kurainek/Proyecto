"""Create Postgres role and database for the app.

Usage (preferred): set env vars and run:

  $env:PG_ADMIN_DSN = "host=localhost dbname=postgres user=postgres password=..."
  python .\scripts\setup_postgres.py

Or use defaults (will attempt to connect as current OS user to localhost).
This script will:
- connect to the admin database (default `postgres`)
- create role `proyecto_user` with password `proyecto_pass` if missing
- create database `proyecto_db` owned by that role if missing

It uses `psycopg2`.
"""
import os
import sys
import psycopg2
from psycopg2 import sql

ADMIN_DSN = os.getenv("PG_ADMIN_DSN")  # full libpq-style connection string
APP_USER = os.getenv("PG_APP_USER", "proyecto_user")
APP_PASS = os.getenv("PG_APP_PASSWORD", "proyecto_pass")
APP_DB = os.getenv("PG_APP_DB", "proyecto_db")


def main():
    dsn = ADMIN_DSN or "host=localhost dbname=postgres"
    print("Conectando a Postgres admin con dsn:", dsn)

    try:
        conn = psycopg2.connect(dsn)
        conn.autocommit = True
    except Exception as e:
        print("No se pudo conectar a Postgres con DSN. Asegura que Postgres esté corriendo.")
        print(e)
        sys.exit(1)

    cur = conn.cursor()

    # Create role if not exists
    cur.execute("SELECT 1 FROM pg_roles WHERE rolname=%s", (APP_USER,))
    if cur.fetchone() is None:
        print(f"Creando rol '{APP_USER}'")
        cur.execute(
            sql.SQL("CREATE ROLE {} WITH LOGIN PASSWORD %s").format(sql.Identifier(APP_USER)),
            [APP_PASS],
        )
    else:
        print(f"Rol '{APP_USER}' ya existe")

    # Create database if not exists
    cur.execute("SELECT 1 FROM pg_database WHERE datname=%s", (APP_DB,))
    if cur.fetchone() is None:
        print(f"Creando base de datos '{APP_DB}' y asignando propietario '{APP_USER}'")
        cur.execute(
            sql.SQL("CREATE DATABASE {} OWNER {}").format(sql.Identifier(APP_DB), sql.Identifier(APP_USER))
        )
    else:
        print(f"Base de datos '{APP_DB}' ya existe")

    cur.close()
    conn.close()
    print("Setup Postgres completado.")


if __name__ == "__main__":
    main()
