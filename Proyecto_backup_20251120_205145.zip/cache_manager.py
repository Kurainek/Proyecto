"""Thread-safe TTL cache with decorator and usage statistics.

Usage:
    @cached(ttl=60)
    def expensive(...):
        ...

Also exposes `CacheManager` for manual operations and `cache_stats()`.
"""
import threading
import time
from functools import wraps
from typing import Any, Callable, Dict, Tuple


class CacheEntry:
    __slots__ = ("value", "expire_at")

    def __init__(self, value: Any, expire_at: float):
        self.value = value
        self.expire_at = expire_at


class CacheManager:
    def __init__(self):
        self._store: Dict[Tuple, CacheEntry] = {}
        self._lock = threading.RLock()
        self.hits = 0
        self.misses = 0

    def get(self, key):
        with self._lock:
            ent = self._store.get(key)
            now = time.time()
            if ent and ent.expire_at > now:
                self.hits += 1
                return ent.value
            if ent:
                # expired
                del self._store[key]
            self.misses += 1
            return None

    def set(self, key, value, ttl: int):
        with self._lock:
            self._store[key] = CacheEntry(value, time.time() + ttl)

    def clear(self):
        with self._lock:
            self._store.clear()

    def stats(self):
        with self._lock:
            total = self.hits + self.misses
            hit_rate = (self.hits / total) if total > 0 else 0.0
            return {"hits": self.hits, "misses": self.misses, "hit_rate": hit_rate}


_global_cache = CacheManager()


def cached(ttl: int = 30):
    """Decorator to cache function results using arguments as key."""

    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            key = (func.__name__, args, tuple(sorted(kwargs.items())))
            val = _global_cache.get(key)
            if val is not None:
                return val
            res = func(*args, **kwargs)
            try:
                _global_cache.set(key, res, ttl)
            except Exception:
                pass
            return res

        return wrapper

    return decorator


def cache_stats():
    return _global_cache.stats()


def clear_cache():
    _global_cache.clear()


__all__ = ["cached", "cache_stats", "clear_cache", "CacheManager"]
