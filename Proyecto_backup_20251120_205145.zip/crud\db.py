"""Database utilities for CRUD operations.

Reads `DATABASE_URL` environment variable (SQLAlchemy URL). If not set,
falls back to a local Postgres default URI suitable for development.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import os

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg2://proyecto_user:proyecto_pass@localhost:5432/proyecto_db",
)

_engine = None
_SessionLocal = None


def get_engine():
    global _engine
    if _engine is None:
        _engine = create_engine(DATABASE_URL)
    return _engine


def get_session():
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(bind=get_engine(), autoflush=False, autocommit=False)
    return _SessionLocal()


def init_db(Base):
    """Create all tables defined on `Base`.

    Use this during initial setup or in tests.
    """
    engine = get_engine()
    Base.metadata.create_all(bind=engine)
