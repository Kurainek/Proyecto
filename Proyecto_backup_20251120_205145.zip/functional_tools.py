"""Utilities demonstrating Python functional constructs.

This small module provides documented, testable examples of:
- filter + lambda
- iter with sentinel
- lambda usage
- list comprehensions
- map
- reduce
- yield (generators)

The functions are intentionally small and pure so you can plug them into the
project or run their tests independently.
"""
from functools import reduce
from typing import Callable, Iterable, Iterator, List, Sequence, TypeVar

T = TypeVar("T")


def filter_even(numbers: Iterable[int]) -> List[int]:
    """Return even numbers using filter + lambda.

    Example:
        filter_even([1,2,3,4])  # -> [2,4]
    """
    return list(filter(lambda x: x % 2 == 0, numbers))


def iter_until_sentinel(callable_obj: Callable[[], T], sentinel: T) -> Iterator[T]:
    """Yield values from `callable_obj()` until it returns `sentinel`.

    Useful for reading lines from a file-like object until an end marker.

    Example:
        it = iter_until_sentinel(lambda: input(), "STOP")
        for line in it:
            print(line)
    """
    for val in iter(callable_obj, sentinel):
        yield val


def apply_map(func: Callable[[T], T], items: Iterable[T]) -> List[T]:
    """Apply `func` to each item using `map` and return a list.

    Example:
        apply_map(lambda x: x*2, [1,2])  # -> [2,4]
    """
    return list(map(func, items))


def list_comp_squares(n: int) -> List[int]:
    """Return list of squares [0..n-1] using list comprehension.

    Example:
        list_comp_squares(4)  # -> [0,1,4,9]
    """
    return [i * i for i in range(n)]


def reduce_sum(numbers: Iterable[float]) -> float:
    """Sum numbers using functools.reduce.

    Example:
        reduce_sum([1,2,3])  # -> 6.0
    """
    return reduce(lambda a, b: a + b, numbers, 0.0)


def generator_range(start: int, stop: int, step: int = 1) -> Iterator[int]:
    """Yield a sequence of numbers lazily (similar to range but demonstrative).

    Example:
        for x in generator_range(0, 5):
            print(x)
    """
    i = start
    while (step > 0 and i < stop) or (step < 0 and i > stop):
        yield i
        i += step


def chunked(iterable: Sequence[T], size: int) -> Iterator[List[T]]:
    """Yield successive chunks (lists) of `size` from `iterable`.

    Implemented using `yield` to stream results.
    """
    if size <= 0:
        raise ValueError("size must be > 0")
    for i in range(0, len(iterable), size):
        yield list(iterable[i : i + size])


def compose_example(numbers: Iterable[int]) -> float:
    """A small composed example using map, filter and reduce.

    Pipeline:
    - keep even numbers (filter)
    - square them (map)
    - sum (reduce)

    Example:
        compose_example([1,2,3,4])  # even:2,4 -> squared:4,16 -> sum:20
    """
    evens = filter(lambda x: x % 2 == 0, numbers)
    squares = map(lambda x: x * x, evens)
    return reduce(lambda a, b: a + b, squares, 0.0)


__all__ = [
    "filter_even",
    "iter_until_sentinel",
    "apply_map",
    "list_comp_squares",
    "reduce_sum",
    "generator_range",
    "chunked",
    "compose_example",
]
