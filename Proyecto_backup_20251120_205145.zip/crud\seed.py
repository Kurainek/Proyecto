"""Seed script to populate initial data for Proyecto.

Reads `DATABASE_URL` env var and inserts sample ingredientes and menus.
"""
from crud.db import get_session, init_db
from crud.models import Base, Ingrediente, Menu, MenuIngrediente


def run_seed():
    # create tables if missing
    init_db(Base)

    session = get_session()
    try:
        # Sample ingredientes
        ingredientes_data = [
            ("Tomate", "unid", 50.0),
            ("Lechuga", "unid", 30.0),
            ("Queso", "kg", 5.0),
            ("Pan", "unid", 100.0),
            ("Pollo", "kg", 10.0),
        ]

        for nombre, unidad, cantidad in ingredientes_data:
            obj = session.query(Ingrediente).filter_by(nombre=nombre).first()
            if not obj:
                obj = Ingrediente(nombre=nombre, unidad=unidad, cantidad=cantidad)
                session.add(obj)

        session.commit()

        # Sample menus
        menu1 = session.query(Menu).filter_by(nombre="Sándwich de Pollo").first()
        if not menu1:
            menu1 = Menu(nombre="Sándwich de Pollo", precio=5.5)
            session.add(menu1)
            session.flush()

            tomate = session.query(Ingrediente).filter_by(nombre="Tomate").first()
            pan = session.query(Ingrediente).filter_by(nombre="Pan").first()
            pollo = session.query(Ingrediente).filter_by(nombre="Pollo").first()

            if tomate and pan and pollo:
                session.add(MenuIngrediente(menu_id=menu1.id, ingrediente_id=tomate.id, cantidad=1))
                session.add(MenuIngrediente(menu_id=menu1.id, ingrediente_id=pan.id, cantidad=1))
                session.add(MenuIngrediente(menu_id=menu1.id, ingrediente_id=pollo.id, cantidad=0.2))

        menu2 = session.query(Menu).filter_by(nombre="Ensalada Mixta").first()
        if not menu2:
            menu2 = Menu(nombre="Ensalada Mixta", precio=4.0)
            session.add(menu2)
            session.flush()

            lechuga = session.query(Ingrediente).filter_by(nombre="Lechuga").first()
            queso = session.query(Ingrediente).filter_by(nombre="Queso").first()

            if lechuga and queso:
                session.add(MenuIngrediente(menu_id=menu2.id, ingrediente_id=lechuga.id, cantidad=1))
                session.add(MenuIngrediente(menu_id=menu2.id, ingrediente_id=queso.id, cantidad=0.05))

        session.commit()
        print("Seed finalizada: ingredientes y menus creados (si no existían).")

    except Exception as e:
        session.rollback()
        print("Error durante seed:", e)
    finally:
        session.close()


if __name__ == "__main__":
    run_seed()
