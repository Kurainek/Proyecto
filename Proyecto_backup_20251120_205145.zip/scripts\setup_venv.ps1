# PowerShell script to create a virtual environment and install dependencies from requirements.txt
# Usage (PowerShell):
#   .\scripts\setup_venv.ps1

$venvPath = "venv"
if (-Not (Test-Path $venvPath)) {
    python -m venv $venvPath
}

# Activate and install
$activate = Join-Path $venvPath "Scripts\Activate.ps1"
if (Test-Path $activate) {
    Write-Host "Activating venv and installing requirements..."
    & $activate; pip install --upgrade pip; pip install -r requirements.txt
} else {
    Write-Host "No se encontró el script de activación. Verifica que Python esté instalado."
}
