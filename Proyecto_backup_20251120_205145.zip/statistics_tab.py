"""Statistics helpers for Proyecto.

Provides simple analytics over the database: top-selling products, sales by
period, and basic trends. Tries to operate safely if DB is not configured.
"""
from typing import List, Tuple
from sqlalchemy import func


def top_products(session, limit: int = 10) -> List[Tuple[str, int]]:
    """Return list of tuples (menu_name, total_quantity_sold).

    If session or tables missing, returns empty list.
    """
    try:
        q = (
            session.query(
                func.coalesce(func.sum("pedido_menus.cantidad"), 0),
            )
        )
    except Exception:
        return []

    # Basic safe fallback: try raw SQL if ORM not available
    try:
        result = session.execute(
            "SELECT m.nombre, SUM(pm.cantidad) as sold FROM pedido_menus pm JOIN menus m ON pm.menu_id = m.id GROUP BY m.nombre ORDER BY sold DESC LIMIT :lim",
            {"lim": limit},
        )
        return [(row[0], int(row[1] or 0)) for row in result]
    except Exception:
        return []


def sales_total(session) -> float:
    """Return total sales from pedido_menus (cantidad * precio_unitario)."""
    try:
        result = session.execute(
            "SELECT SUM(cantidad * precio_unitario) FROM pedido_menus"
        ).scalar()
        return float(result or 0.0)
    except Exception:
        return 0.0


__all__ = ["top_products", "sales_total"]
