import pytest
from functional_tools import (
    filter_even,
    list_comp_squares,
    reduce_sum,
    apply_map,
    generator_range,
    chunked,
    compose_example,
)


def test_filter_even():
    assert filter_even([1,2,3,4,5,6]) == [2,4,6]


def test_list_comp_squares():
    assert list_comp_squares(5) == [0,1,4,9,16]


def test_reduce_sum():
    assert reduce_sum([1,2,3.5]) == pytest.approx(6.5)


def test_apply_map():
    assert apply_map(lambda x: x*2, [1,2,3]) == [2,4,6]


def test_generator_range_and_chunked():
    assert list(generator_range(0,5)) == [0,1,2,3,4]
    assert list(chunked([1,2,3,4,5], 2)) == [[1,2],[3,4],[5]]


def test_compose_example():
    assert compose_example([1,2,3,4]) == 20.0
