import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from crud.models import Base, Menu, Pedido, PedidoMenu
from statistics_tab import top_products, sales_total


@pytest.fixture()
def sqlite_session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    try:
        yield session
+    finally:
+        session.close()
+
+
+def test_statistics_basic(sqlite_session):
+    session = sqlite_session
+
+    # Crear menus
+    m1 = Menu(nombre="Menu A", precio=10.0)
+    m2 = Menu(nombre="Menu B", precio=7.5)
+    session.add_all([m1, m2])
+    session.flush()
+
+    # Crear un pedido y items
+    p1 = Pedido(cliente="Cliente 1")
+    session.add(p1)
+    session.flush()
+
+    # PedidoMenu: 3 x Menu A @10, 2 x Menu B @7.5
+    item1 = PedidoMenu(pedido_id=p1.id, menu_id=m1.id, cantidad=3, precio_unitario=10.0)
+    item2 = PedidoMenu(pedido_id=p1.id, menu_id=m2.id, cantidad=2, precio_unitario=7.5)
+    session.add_all([item1, item2])
+    session.commit()
+
+    top = top_products(session, limit=10)
+    # top should contain Menu A first with 3 sold, then Menu B with 2
+    assert isinstance(top, list)
+    assert len(top) >= 2
+    assert top[0][0] == "Menu A"
+    assert int(top[0][1]) == 3
+    assert top[1][0] == "Menu B"
+    assert int(top[1][1]) == 2
+
+    total = sales_total(session)
+    # total = 3*10 + 2*7.5 = 30 + 15 = 45
+    assert float(total) == pytest.approx(45.0)
