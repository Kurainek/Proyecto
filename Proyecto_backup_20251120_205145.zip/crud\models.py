"""SQLAlchemy models for Proyecto.

Includes:
- Ingrediente
- Menu
- MenuIngrediente (association)
- Pedido
- PedidoMenu (association)
"""
from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    ForeignKey,
    Table,
)
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()


class Ingrediente(Base):
    __tablename__ = "ingredientes"

    id = Column(Integer, primary_key=True)
    nombre = Column(String(120), unique=True, nullable=False)
    unidad = Column(String(32), nullable=False, default="unid")
    cantidad = Column(Float, nullable=False, default=0.0)

    def __repr__(self) -> str:  # pragma: no cover - simple repr
        return f"<Ingrediente {self.nombre} ({self.cantidad} {self.unidad})>"


class Menu(Base):
    __tablename__ = "menus"

    id = Column(Integer, primary_key=True)
    nombre = Column(String(120), unique=True, nullable=False)
    precio = Column(Float, nullable=False, default=0.0)

    ingredientes = relationship("MenuIngrediente", back_populates="menu", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Menu {self.nombre} ${self.precio:.2f}>"


class MenuIngrediente(Base):
    __tablename__ = "menu_ingredientes"

    id = Column(Integer, primary_key=True)
    menu_id = Column(Integer, ForeignKey("menus.id"), nullable=False)
    ingrediente_id = Column(Integer, ForeignKey("ingredientes.id"), nullable=False)
    cantidad = Column(Float, nullable=False, default=0.0)

    menu = relationship("Menu", back_populates="ingredientes")
    ingrediente = relationship("Ingrediente")

    def __repr__(self) -> str:
        return f"<MenuIngrediente menu_id={self.menu_id} ingrediente_id={self.ingrediente_id} qty={self.cantidad}>"


class Pedido(Base):
    __tablename__ = "pedidos"

    id = Column(Integer, primary_key=True)
    cliente = Column(String(120), nullable=True)

    items = relationship("PedidoMenu", back_populates="pedido", cascade="all, delete-orphan")

    def calcular_total(self) -> float:
        return sum(item.cantidad * item.precio_unitario for item in self.items)


class PedidoMenu(Base):
    __tablename__ = "pedido_menus"

    id = Column(Integer, primary_key=True)
    pedido_id = Column(Integer, ForeignKey("pedidos.id"), nullable=False)
    menu_id = Column(Integer, ForeignKey("menus.id"), nullable=False)
    cantidad = Column(Integer, nullable=False, default=1)
    precio_unitario = Column(Float, nullable=False, default=0.0)

    pedido = relationship("Pedido", back_populates="items")
    menu = relationship("Menu")

    def __repr__(self) -> str:
        return f"<PedidoMenu menu_id={self.menu_id} qty={self.cantidad}>"
