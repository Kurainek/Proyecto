"""Manejo centralizado de errores y validación.

Provee:
- Excepciones personalizadas (StockException, PedidoException, ValidationException)
- Decorador `handle_errors` para capturar excepciones en capas UI/operación
- Registro consistente en consola y archivo
"""
from functools import wraps
import logging
from tkinter import messagebox

logger = logging.getLogger("restaurante.errors")
logger.setLevel(logging.INFO)
if not logger.handlers:
    fh = logging.FileHandler("restaurante.log")
    fh.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    fh.setFormatter(fmt)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(fmt)
    logger.addHandler(fh)
    logger.addHandler(ch)


class StockException(Exception):
    pass


class PedidoException(Exception):
    pass


class ValidationException(Exception):
    pass


def handle_errors(user_message: str = None):
    """Decorator to handle exceptions, log them and show a consistent messagebox.

    If `user_message` is provided it will be shown to the user; otherwise the
    exception message will be used.
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except (StockException, PedidoException, ValidationException) as exc:
                logger.exception("Handled domain exception")
                msg = user_message or str(exc) or exc.__class__.__name__
                try:
                    messagebox.showerror(title="Error", message=msg)
                except Exception:
                    # If UI not available, still log
                    logger.error("UI not available to display error: %s", msg)
            except Exception as exc:  # pragma: no cover - top-level safety
                logger.exception("Unhandled exception in %s", func.__name__)
                msg = user_message or "Ocurrió un error inesperado. Revisa el log."
                try:
                    messagebox.showerror(title="Error inesperado", message=msg)
                except Exception:
                    logger.error("UI not available to display unexpected error: %s", msg)
        return wrapper
    return decorator
