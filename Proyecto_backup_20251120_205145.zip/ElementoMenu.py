from dataclasses import dataclass, field
from typing import List, Optional

from Ingrediente import Ingrediente
from Stock import Stock
from IMenu import IMenu


@dataclass
class CrearMenu(IMenu):
    nombre: str
    ingredientes: List[Ingrediente]
    precio: float = 0.0
    icono_path: Optional[str] = None
    cantidad: int = field(default=0, compare=False)

    def esta_disponible(self, stock: Stock) -> bool:
        for req in self.ingredientes:
            disponible = False
            req_nombre = req.nombre.strip().lower()
            req_unidad = None
            if req.unidad:
                req_unidad = req.unidad.strip().lower()

            for ing in stock.lista_ingredientes:
                ing_nombre = ing.nombre.strip().lower()
                ing_unidad = None
                if ing.unidad:
                    ing_unidad = ing.unidad.strip().lower()

                if ing_nombre == req_nombre:
                    if req_unidad is None or ing_unidad == req_unidad:
                        try:
                            ing_cant = float(ing.cantidad)
                            req_cant = float(req.cantidad)
                            if ing_cant >= req_cant:
                                disponible = True
                                break
                        except Exception:
                            # Si los datos no son numéricos, saltar este ingrediente
                            continue

            if not disponible:
                return False

        return True

    def preparar(self, stock: Stock) -> None:
        for req in self.ingredientes:
            req_nombre = req.nombre.strip().lower()
            req_unidad = None
            if req.unidad:
                req_unidad = req.unidad.strip().lower()

            for ing in stock.lista_ingredientes:
                ing_nombre = ing.nombre.strip().lower()
                ing_unidad = None
                if ing.unidad:
                    ing_unidad = ing.unidad.strip().lower()

                if ing_nombre == req_nombre:
                    if req_unidad is None or ing_unidad == req_unidad:
                        try:
                            ing.cantidad = float(ing.cantidad) - float(req.cantidad)
                            if ing.cantidad < 0:
                                ing.cantidad = 0
                        except Exception:
                            # si hay datos inválidos, evitamos romper la preparación
                            pass
                        break

















