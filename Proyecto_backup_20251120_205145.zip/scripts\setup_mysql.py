"""Create MySQL user and database for the app (phpMyAdmin compatible).

Usage (PowerShell):

  $env:MYSQL_ADMIN_HOST = "localhost"
  $env:MYSQL_ADMIN_USER = "root"
  $env:MYSQL_ADMIN_PASSWORD = "root_password"
  python .\scripts\setup_mysql.py

This script will:
- connect to MySQL as admin/root
- create user `proyecto_user` with password `proyecto_pass` if missing
- create database `proyecto_db` if missing and grant privileges

Requires `PyMySQL` (included in `requirements.txt`).
"""
import os
import sys

import pymysql

ADMIN_HOST = os.getenv("MYSQL_ADMIN_HOST", "localhost")
ADMIN_USER = os.getenv("MYSQL_ADMIN_USER", "root")
ADMIN_PASS = os.getenv("MYSQL_ADMIN_PASSWORD", "")
ADMIN_PORT = int(os.getenv("MYSQL_ADMIN_PORT", "3306"))

APP_USER = os.getenv("MYSQL_APP_USER", "proyecto_user")
APP_PASS = os.getenv("MYSQL_APP_PASSWORD", "proyecto_pass")
APP_DB = os.getenv("MYSQL_APP_DB", "proyecto_db")


def main():
    print(f"Conectando a MySQL en {ADMIN_HOST}:{ADMIN_PORT} como {ADMIN_USER}")
    try:
        conn = pymysql.connect(host=ADMIN_HOST, user=ADMIN_USER, password=ADMIN_PASS, port=ADMIN_PORT)
    except Exception as e:
        print("No se pudo conectar a MySQL. Asegura que el servicio esté corriendo y las credenciales sean correctas.")
        print(e)
        sys.exit(1)

    try:
        with conn.cursor() as cur:
            # Create database if not exists
            cur.execute("CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci" % APP_DB)
            print(f"Base de datos '{APP_DB}' creada o ya existía")

            # Create user if not exists (MySQL 5.7+/8 syntax)
            cur.execute("SELECT COUNT(*) FROM mysql.user WHERE user=%s", (APP_USER,))
            exists = cur.fetchone()[0] > 0
            if not exists:
                cur.execute(
                    "CREATE USER %s@'%%' IDENTIFIED BY %s",
                    (APP_USER, APP_PASS),
                )
                print(f"Usuario '{APP_USER}' creado")
            else:
                print(f"Usuario '{APP_USER}' ya existe")

            # Grant privileges
            cur.execute("GRANT ALL PRIVILEGES ON `%s`.* TO %s@'%%'" % (APP_DB, APP_USER))
            cur.execute("FLUSH PRIVILEGES")
            print(f"Privilegios concedidos a '{APP_USER}' sobre '{APP_DB}'")

        conn.commit()
    finally:
        conn.close()

    print("Setup MySQL completado.")


if __name__ == "__main__":
    main()
